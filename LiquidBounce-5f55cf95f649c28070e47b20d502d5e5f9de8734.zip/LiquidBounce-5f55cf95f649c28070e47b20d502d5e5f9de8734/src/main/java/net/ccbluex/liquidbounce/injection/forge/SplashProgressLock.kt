package net.ccbluex.liquidbounce.injection.forge

object SplashProgressLock {
    var isAnimationRunning = true
}